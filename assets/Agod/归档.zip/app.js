$.post('/index/plugin/authCheck', {}, function (data) {
    if (data.code == 0)
    {
        alert(data.msg);
    }
})

function is_pwd_not_need() {
    //更新部分
    $("#is_pwdforsearch").val(1);
    var pwdforsearch2 = $("input[name='pwdforsearch2']").val();
    if ((pwdforsearch2.length >= 1 && pwdforsearch2.length < 6) || (pwdforsearch1.length > 20)) {
        alert('您输入的取卡密码 不是6-20位！');
        $('[name=pwdforsearch1]').focus();
        $('#check_pay').attr("disabled", true);
        return false;
    } else {
        $('#check_pay').removeAttribute("disabled");
    }
}

function checkCoupon2() {
    var couponcode = $.trim($('[name=couponcode]').val());
    if (cateid == 0) {
        cateid = $('#cateid').val();
    }
    $.post('/ajax/checkcoupon', {
        couponcode: couponcode,
        userid: userid,
        cateid: cateid,
        t: new Date().getTime()
    }, function (data) {
        if (data) {
            data = eval(data);
            if (data.result == 0) {
                layer.msg(data.msg, {icon: 2, time: 3000});
                $('#checkcoupon').html(data.msg);
                $('[name=is_coupon]').val("0");//更新部分
            } else if (data.result == 1) {
                layer.msg('优惠卷可用', {icon: 1, time: 3000});
                $('[name=coupon_ctype]').val(data.ctype);
                $('[name=coupon_value]').val(data.coupon);
                $('[name=is_coupon]').val("1");//更新部分
                goodschk();
            } else {
                layer.msg(data.msg, {icon: 2, time: 3000});
                $('#checkcoupon').html('验证失败！');
            }
        }
    }, "json");
}



$(function () {

    $('#isemail').click(function () {

        if ($(this).prop('checked')) {
            $(this).attr('checked', true);
            $(this).parent().parent().addClass("on");
        } else {
            $(this).attr('checked', false);
            $(this).parent().parent().removeClass("on");
        }

        $('#is_rev_sms').attr('checked', false);
        $(".sms_btn").removeClass("on");
        $('[name=sms_price]').val(0);

        $('.email_show').stop().fadeToggle();
        $('.email_show').find('input').focus();

        if ($('#is_rev_sms').attr('checked')) {
            $('.phone_num').focus().attr('placeholder', '请填写你的手机号');
            $(".sms_btn").addClass("on");
        } else {
            $('.phone_num').blur().attr('placeholder', '推荐填写QQ号或手机号');
            $(".sms_btn").removeClass("on");
        }

    });
    $('#youhui').click(function () {

        $('.youhui_show').stop().fadeToggle();
        $('.youhui_show').find('input').focus();

        if ($(this).prop('checked')) {
            $(this).attr('checked', true);
            $(this).parent().parent().addClass("on");
        } else {
            $(this).attr('checked', false);
            $(this).parent().parent().removeClass("on");
        }

    });
    $('#is_rev_sms').click(function () {
        if ($(this).prop('checked')) {
            $(this).attr('checked', true);
            $(this).parent().parent().addClass("on");
        } else {
            $(this).attr('checked', false);
            $(this).parent().parent().removeClass("on");
        }


        $('#isemail').attr('checked', false);
        $(".email_btn").removeClass("on");


        $('.email_show').stop().fadeOut();
        if ($(this).attr('checked')) {
            $('.phone_num').focus().attr('placeholder', '请填写你的手机号');
            $(".sms_btn").addClass("on");
        } else {
            $('.phone_num').blur().attr('placeholder', '推荐填写QQ号或手机号');
            $(".sms_btn").removeClass("on");
        }
    });

});

$(document).on('click', '.pay_type_leng', function () {
    $(this).addClass("pay_type_leng_xz");
    $(this).siblings().removeClass("pay_type_leng_xz");
    $('[name=pid]').val($(this).data("pid"));
    $('[name=fee_rate]').val($(this).data("rate"));
    goodschk();
});

$(document).on('click', '.category_box', function () {
    $(this).addClass("active");
    $(this).siblings().removeClass("active");
    $('[name=cateid]').val($(this).data("cateid"));
    selectcateid();
});


$(document).on('click', '.goods_box', function () {
    $(this).addClass("active");
    $(this).siblings().removeClass("active");
    $('[name=goodid]').val($(this).data("goods_id"));
    selectgoodid();
});


$(document).on('click', '.shuliang_box .btn:eq(0)', function () {
    var limit_quantity = $('[name=limit_quantity]').val();
    var quantity = parseInt($('.shuliang_box input').val());
    if (quantity - 1 < limit_quantity)
    {
        layer.msg("最少购买" + limit_quantity + "件");
    } else {
        $('.shuliang_box input').val(quantity - 1);
        changequantity();
    }
});

$(document).on('click', '.shuliang_box .btn:eq(1)', function () {
    var quantity = parseInt($('.shuliang_box input').val());
    $('.shuliang_box input').val(quantity + 1);
    changequantity();
});

$('.category_box:first').click();
$('.pay_type_leng:first').click();